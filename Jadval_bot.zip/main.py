import os
from aiogram import Bot, Dispatcher, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils import executor
from aiogram.contrib.middlewares.logging import LoggingMiddleware
from aiogram.types import ParseMode
from aiogram.utils.exceptions import TelegramAPIError
from aiohttp import web
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher import FSMContext
from aiogram.contrib.middlewares import BaseMiddleware

API_TOKEN = os.getenv('BOT_API_TOKEN')
CHANNEL_ID = "-1002464209662"

SCHEDULE_MESSAGE_IDS = {
    "5-A": {"Dushanba": 3, "Seshanba": 4, "Chorshanba": 5, "Payshanba": 6, "Juma": 7},
    "5-B": {"Dushanba": 9, "Seshanba": 10, "Chorshanba": 11, "Payshanba": 12, "Juma": 13},
    "5-D": {"Dushanba": 16, "Seshanba": 17, "Chorshanba": 18, "Payshanba": 19, "Juma": 20},
    "6-A": {"Dushanba": 22, "Seshanba": 23, "Chorshanba": 24, "Payshanba": 25, "Juma": 26},
    "6-B": {"Dushanba": 28, "Seshanba": 29, "Chorshanba": 30, "Payshanba": 31, "Juma": 32},
    "6-D": {"Dushanba": 34, "Seshanba": 35, "Chorshanba": 36, "Payshanba": 37, "Juma": 38},
    "7-A": {"Dushanba": 40, "Seshanba": 41, "Chorshanba": 42, "Payshanba": 43, "Juma": 44},
    "7-B": {"Dushanba": 46, "Seshanba": 47, "Chorshanba": 48, "Payshanba": 49, "Juma": 50},
    "7-D": {"Dushanba": 52, "Seshanba": 53, "Chorshanba": 54, "Payshanba": 55, "Juma": 56},
    "8-A": {"Dushanba": 58, "Seshanba": 59, "Chorshanba": 60, "Payshanba": 61, "Juma": 62},
    "8-B": {"Dushanba": 64, "Seshanba": 65, "Chorshanba": 66, "Payshanba": 67, "Juma": 68},
    "8-D": {"Dushanba": 70, "Seshanba": 71, "Chorshanba": 72, "Payshanba": 73, "Juma": 74},
    "9-A": {"Dushanba": 76, "Seshanba": 77, "Chorshanba": 78, "Payshanba": 79, "Juma": 80},
    "9-B": {"Dushanba": 82, "Seshanba": 83, "Chorshanba": 84, "Payshanba": 85, "Juma": 86},
    "9-D": {"Dushanba": 88, "Seshanba": 89, "Chorshanba": 90, "Payshanba": 91, "Juma": 92},
    "10-A": {"Dushanba": 94, "Seshanba": 95, "Chorshanba": 96, "Payshanba": 97, "Juma": 98},
    "10-B": {"Dushanba": 100, "Seshanba": 101, "Chorshanba": 102, "Payshanba": 103, "Juma": 104},
    "10-D": {"Dushanba": 106, "Seshanba": 107, "Chorshanba": 108, "Payshanba": 19, "Juma": 110},
    "11-A": {"Dushanba": 112, "Seshanba": 113, "Chorshanba": 114, "Payshanba": 115, "Juma": 116},
    "11-B": {"Dushanba": 118, "Seshanba": 119, "Chorshanba": 120, "Payshanba": 121, "Juma": 122},
    "11-D": {"Dushanba": 124, "Seshanba": 125, "Chorshanba": 126, "Payshanba": 127, "Juma": 128},
}

# Create bot and dispatcher
bot = Bot(token=API_TOKEN, parse_mode=ParseMode.MARKDOWN)
dp = Dispatcher(bot)
dp.middleware.setup(LoggingMiddleware())

# FSM State Definition
class ScheduleState(StatesGroup):
    waiting_for_class = State()  # Will wait for class
    waiting_for_day = State()    # Will wait for day

# Webhook settings
WEBHOOK_PATH = '/webhook'
WEBHOOK_URL = "https://webhookjadval.onrender.com"

async def on_start(message: types.Message):
    keyboard = InlineKeyboardMarkup(row_width=2)
    group_1 = ["5-A", "5-B", "5-D"]
    group_2 = ["6-A", "6-B", "6-D"]
    group_3 = ["7-A", "7-B", "7-D"]
    group_4 = ["8-A", "8-B", "8-D"]
    group_5 = ["9-A", "9-B", "9-D"]
    group_6 = ["10-A", "10-B", "10-D"]
    group_7 = ["11-A", "11-B", "11-D"]

    for group in [group_1, group_2, group_3, group_4, group_5, group_6, group_7]:
        row = [InlineKeyboardButton(sinf, callback_data=sinf) for sinf in group]
        keyboard.row(*row)

    await message.answer("Assalomu alaykum, qaysi sinfning dars jadvalini ko‘rmoqchisiz?", reply_markup=keyboard)
    await ScheduleState.waiting_for_class.set()  # Set FSM to wait for class selection

@dp.callback_query_handler(state=ScheduleState.waiting_for_class)
async def select_class(call: types.CallbackQuery, state: FSMContext):
    sinf = call.data
    await state.update_data(chosen_class=sinf)  # Store chosen class in FSM state
    keyboard = InlineKeyboardMarkup(row_width=2)
    for kun in SCHEDULE_MESSAGE_IDS[sinf].keys():
        keyboard.add(InlineKeyboardButton(kun, callback_data=f"{sinf}:{kun}"))
    await call.message.edit_text(f"{sinf} sinf tanlandi, endi hafta kunini tanlang!", reply_markup=keyboard)
    await ScheduleState.waiting_for_day.set()  # Set FSM to wait for day selection

@dp.callback_query_handler(state=ScheduleState.waiting_for_day)
async def select_day(call: types.CallbackQuery, state: FSMContext):
    sinf, kun = call.data.split(":")
    user_data = await state.get_data()
    chosen_class = user_data.get("chosen_class")

    if chosen_class in SCHEDULE_MESSAGE_IDS and kun in SCHEDULE_MESSAGE_IDS[chosen_class]:
        try:
            message_id = SCHEDULE_MESSAGE_IDS[chosen_class][kun]
            await bot.forward_message(chat_id=call.message.chat.id, from_chat_id=CHANNEL_ID, message_id=message_id)
            await state.finish()  # Finish FSM state after sending the schedule
        except TelegramAPIError as e:
            await call.message.answer("Xatolik yuz berdi!")
    else:
        await call.message.answer("Noto'g'ri sinf yoki kun tanlandi.")

async def on_start_webhook(request):
    json_str = await request.json()
    update = types.Update(**json_str)
    await dp.process_update(update)
    return web.Response(status=200)

def on_start_webhook_runner():
    app = web.Application()
    app.router.add_post(WEBHOOK_PATH, on_start_webhook)
    return app

if __name__ == '__main__':
    from aiohttp import web
    app = on_start_webhook_runner()

    # Setting the webhook
    bot.set_webhook(WEBHOOK_URL)

    # Running the web server
    web.run_app(app, host='0.0.0.0', port=5000)